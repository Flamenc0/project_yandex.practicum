const endpoints = require("./config");
const {getData, getRandomGame} = require("./api-utils")

module.exports = {getData, getRandomGame, endpoints }